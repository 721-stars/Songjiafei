import collections
class Solution:
    def firstUniqChar(self, s):
        # build hash map : character and how often it appears
        count = collections.Counter(s)
        # find the index
        index = 0
        for i in s:
            if count[i] == 1:
                return index
            else:
                index += 1
        return -1

s1 = Solution()
s="loveleetcode"
print(s1.firstUniqChar(s))
