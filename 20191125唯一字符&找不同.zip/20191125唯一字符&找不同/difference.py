class Solution:
    def findTheDifference(self, s: str, t: str) -> str:
        res = {}
        for i in s:
            if res.get(i):
                res[i] += 1  #记录s中的字符出现次数
            else:
                res[i] = 1

        for i in t:
            if res.get(i):   #消除字典中存在的字符
                res[i] -= 1
            else:
                return i     #字典中没有相同字符，则返回该字符
s1 = Solution()
s="abcde"
t="abcdeg"
print(s1.findTheDifference(s,t))